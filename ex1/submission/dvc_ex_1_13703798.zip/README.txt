UZH: Data Visualisation Concepts

GitHub URL: https://github.com/mbbuehler/DVC

Execution:

    Start iPython notebook:
    $ jupyter notebook or $ ipython notebook
    In the browser, navigate to the solutions for assignment 1:
    Assignment1.ipynb
    After opening Assignment1, click "Cell"->"Run All". Without this step, the interactive text inputs and dropdowns are not displayed.

Make sure you use python 3 to execute code with at minimum the following modules available (non-complete list):

    plotly
    cufflinks
    pandas
    numpy
    ipywidgets
    re

IDE used: PyCharm 5.0.5 Professional Edition
